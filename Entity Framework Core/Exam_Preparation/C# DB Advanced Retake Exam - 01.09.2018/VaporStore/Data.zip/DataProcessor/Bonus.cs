﻿namespace VaporStore.DataProcessor
{
	using System;
	using Data;

	public static class Bonus
	{
		public static string UpdateEmail(VaporStoreDbContext context, string username, string newEmail)
		{
			throw new NotImplementedException();
		}
	}
}
