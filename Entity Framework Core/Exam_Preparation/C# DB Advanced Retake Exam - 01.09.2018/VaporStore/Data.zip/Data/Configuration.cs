﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-MU23NJN\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}