﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    internal static class Configuration
    {
        internal static string Connection = @"Server =DESKTOP-8TA8JKL\\SQLEXPRESS;Database = HospitalDb; Integrated Security = true;";
    }
}
