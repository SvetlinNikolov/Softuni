﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
   internal static class Configuration
    {
        internal static string ConnectionString =
            @"Server = DESKTOP-MU23NJN\SQLEXPRESS;Database = SalesDatabase; Integrated Security = true";
    }
}
