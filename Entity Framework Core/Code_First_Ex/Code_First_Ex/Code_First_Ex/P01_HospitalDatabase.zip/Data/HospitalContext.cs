﻿
namespace P01_HospitalDatabase.Data
{
    using Microsoft.EntityFrameworkCore;
    using Data.Models;

    public class HospitalContext
    {
        protected void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                optionsBuilder.UseSqlServer("Server =DESKTOP-8TA8JKL\\SQLEXPRESS;Database = Softuni; Integrated Security = true;");
            }
        }

    }
}
