﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Design_Patterns_Ex
{
   public abstract class SandwichPrototype
    {

        public abstract SandwichPrototype Clone();
      
    }
}
